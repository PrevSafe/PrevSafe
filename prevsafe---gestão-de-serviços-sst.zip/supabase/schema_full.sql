-- ==============================================================================
-- PREVSAFE SST - SCHEMA COMPLETO PARA SUPABASE (POSTGRESQL)
-- ==============================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE 'plpgsql';

-- 1. ORGANIZATIONS
CREATE TABLE IF NOT EXISTS public.organizations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  legal_name TEXT NOT NULL,
  document_number TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  logo_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2. PROFILES
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organization_id UUID REFERENCES public.organizations(id) ON DELETE CASCADE,
  user_id UUID,
  full_name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  role TEXT NOT NULL CHECK (role IN ('ADMIN', 'COMMERCIAL', 'COORDINATOR', 'ENGINEER_TECHNICIAN', 'CLIENT', 'DOCTOR')),
  client_id UUID,
  avatar_url TEXT,
  phone TEXT,
  crm_crea_number TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 3. CLIENTS
CREATE TABLE IF NOT EXISTS public.clients (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organization_id UUID REFERENCES public.organizations(id) ON DELETE CASCADE,
  trade_name TEXT NOT NULL,
  legal_name TEXT NOT NULL,
  cnpj TEXT NOT NULL UNIQUE,
  tax_id TEXT,
  cnae TEXT,
  cnae_description TEXT,
  risk_degree INTEGER DEFAULT 1 CHECK (risk_degree BETWEEN 1 AND 4),
  total_employees INTEGER DEFAULT 0,
  address_street TEXT,
  address_number TEXT,
  address_neighborhood TEXT,
  address_city TEXT,
  address_state TEXT,
  address_zip TEXT,
  portal_access_enabled BOOLEAN DEFAULT true,
  status TEXT DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'INACTIVE', 'SUSPENDED')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 4. CLIENT CONTACTS
CREATE TABLE IF NOT EXISTS public.client_contacts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  client_id UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  role TEXT,
  email TEXT NOT NULL,
  phone TEXT,
  is_primary BOOLEAN DEFAULT false,
  is_financial BOOLEAN DEFAULT false,
  is_technical BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 5. CLIENT UNITS
CREATE TABLE IF NOT EXISTS public.client_units (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  client_id UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  cnpj TEXT,
  cnae TEXT,
  risk_degree INTEGER DEFAULT 1 CHECK (risk_degree BETWEEN 1 AND 4),
  employees_count INTEGER DEFAULT 0,
  city TEXT,
  state TEXT,
  is_headquarters BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 6. SECTORS
CREATE TABLE IF NOT EXISTS public.sst_sectors (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  client_id UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  unit_id UUID REFERENCES public.client_units(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  description TEXT,
  environment_characteristics TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 7. ROLES (CBO)
CREATE TABLE IF NOT EXISTS public.sst_roles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  client_id UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  cbo_code TEXT NOT NULL,
  description TEXT,
  ghe_code TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 8. EMPLOYEES
CREATE TABLE IF NOT EXISTS public.sst_employees (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  client_id UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  unit_id UUID REFERENCES public.client_units(id) ON DELETE SET NULL,
  sector_id UUID REFERENCES public.sst_sectors(id) ON DELETE SET NULL,
  role_id UUID REFERENCES public.sst_roles(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  cpf TEXT NOT NULL,
  rg TEXT,
  birth_date DATE,
  gender TEXT CHECK (gender IN ('M', 'F', 'OUTRO')),
  admission_date DATE NOT NULL,
  dismissal_date DATE,
  registration_number TEXT,
  ctps_number TEXT,
  ctps_series TEXT,
  is_pcd BOOLEAN DEFAULT false,
  status TEXT DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'AWAY', 'VACATION', 'DISMISSED')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 9. LEADS
CREATE TABLE IF NOT EXISTS public.leads (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organization_id UUID REFERENCES public.organizations(id) ON DELETE CASCADE,
  company_name TEXT NOT NULL,
  contact_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  cnpj TEXT,
  employees_count INTEGER,
  source TEXT,
  status TEXT DEFAULT 'NEW' CHECK (status IN ('NEW', 'CONTACTED', 'QUALIFIED', 'PROPOSAL_SENT', 'WON', 'LOST')),
  assigned_to UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 10. OPPORTUNITIES
CREATE TABLE IF NOT EXISTS public.opportunities (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organization_id UUID REFERENCES public.organizations(id) ON DELETE CASCADE,
  lead_id UUID REFERENCES public.leads(id) ON DELETE SET NULL,
  client_id UUID REFERENCES public.clients(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  estimated_value NUMERIC(12,2) DEFAULT 0.00,
  stage TEXT DEFAULT 'QUALIFICATION' CHECK (stage IN ('QUALIFICATION', 'PROPOSAL_DRAFT', 'NEGOTIATION', 'CLOSED_WON', 'CLOSED_LOST')),
  probability INTEGER DEFAULT 20 CHECK (probability BETWEEN 0 AND 100),
  expected_close_date DATE,
  assigned_to UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 11. SERVICE TEMPLATES
CREATE TABLE IF NOT EXISTS public.service_templates (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organization_id UUID REFERENCES public.organizations(id) ON DELETE CASCADE,
  code TEXT NOT NULL,
  name TEXT NOT NULL,
  category TEXT NOT NULL CHECK (category IN ('PGR', 'PCMSO', 'LTCAT', 'LAUDO_INSALUBRIDADE', 'LAUDO_PERICULOSIDADE', 'TREINAMENTO', 'CONSULTORIA', 'ESOCIAL', 'CIPA')),
  description TEXT,
  default_price NUMERIC(12,2) DEFAULT 0.00,
  standard_sla_days INTEGER DEFAULT 15,
  default_stages JSONB DEFAULT '[]'::jsonb,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 12. PROPOSALS
CREATE TABLE IF NOT EXISTS public.proposals (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organization_id UUID REFERENCES public.organizations(id) ON DELETE CASCADE,
  proposal_number TEXT NOT NULL UNIQUE,
  client_id UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  opportunity_id UUID REFERENCES public.opportunities(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  description TEXT,
  subtotal NUMERIC(12,2) DEFAULT 0.00,
  discount NUMERIC(12,2) DEFAULT 0.00,
  total NUMERIC(12,2) DEFAULT 0.00,
  status TEXT DEFAULT 'DRAFT' CHECK (status IN ('DRAFT', 'SENT', 'APPROVED', 'REJECTED', 'CONVERTED_CONTRACT')),
  valid_until DATE NOT NULL,
  items JSONB DEFAULT '[]'::jsonb,
  history JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 13. CONTRACTS
CREATE TABLE IF NOT EXISTS public.contracts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organization_id UUID REFERENCES public.organizations(id) ON DELETE CASCADE,
  contract_number TEXT NOT NULL UNIQUE,
  proposal_id UUID REFERENCES public.proposals(id) ON DELETE SET NULL,
  client_id UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  total_value NUMERIC(12,2) DEFAULT 0.00,
  billing_recurrence TEXT DEFAULT 'ONE_TIME' CHECK (billing_recurrence IN ('ONE_TIME', 'MONTHLY', 'ANNUAL')),
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  status TEXT DEFAULT 'DRAFT' CHECK (status IN ('DRAFT', 'PENDING_SIGNATURES', 'SIGNED', 'ACTIVE', 'EXPIRED', 'TERMINATED')),
  signatures JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 14. SERVICE ORDERS
CREATE TABLE IF NOT EXISTS public.service_orders (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organization_id UUID REFERENCES public.organizations(id) ON DELETE CASCADE,
  os_number TEXT NOT NULL UNIQUE,
  contract_id UUID REFERENCES public.contracts(id) ON DELETE SET NULL,
  client_id UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  service_template_id UUID REFERENCES public.service_templates(id) ON DELETE SET NULL,
  service_name TEXT NOT NULL,
  technical_responsible_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  technical_responsible_name TEXT,
  status TEXT DEFAULT 'NOT_STARTED' CHECK (status IN ('NOT_STARTED', 'IN_PROGRESS', 'WAITING_CLIENT', 'INTERNAL_REVIEW', 'COMPLETED', 'CANCELED')),
  start_date DATE,
  due_date DATE NOT NULL,
  completed_at TIMESTAMPTZ,
  sla_internal_days INTEGER DEFAULT 15,
  sla_client_waiting_days INTEGER DEFAULT 0,
  sla_is_paused BOOLEAN DEFAULT false,
  sla_pause_reason TEXT,
  stages JSONB DEFAULT '[]'::jsonb,
  rework_history JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 15. PGR INVENTORY (NR-01)
CREATE TABLE IF NOT EXISTS public.sst_pgr_inventory (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  client_id UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  sector_id UUID REFERENCES public.sst_sectors(id) ON DELETE CASCADE,
  role_id UUID REFERENCES public.sst_roles(id) ON DELETE SET NULL,
  danger_description TEXT NOT NULL,
  risk_factor_category TEXT NOT NULL CHECK (risk_factor_category IN ('FISICO', 'QUIMICO', 'BIOLOGICO', 'ERGONOMICO', 'ACIDENTE')),
  esocial_code TEXT,
  possible_harms TEXT,
  exposed_workers_count INTEGER DEFAULT 1,
  probability_level INTEGER DEFAULT 1 CHECK (probability_level BETWEEN 1 AND 5),
  severity_level INTEGER DEFAULT 1 CHECK (severity_level BETWEEN 1 AND 5),
  risk_level INTEGER GENERATED ALWAYS AS (probability_level * severity_level) STORED,
  risk_classification TEXT CHECK (risk_classification IN ('TRIVIAL', 'TOLERAVEL', 'MODERADO', 'SUBSTANCIAL', 'INTOLERAVEL')),
  existing_controls JSONB DEFAULT '[]'::jsonb,
  proposed_controls JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 16. ASOS (NR-07 / S-2220)
CREATE TABLE IF NOT EXISTS public.sst_asos (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  client_id UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  employee_id UUID NOT NULL REFERENCES public.sst_employees(id) ON DELETE CASCADE,
  exam_type TEXT NOT NULL CHECK (exam_type IN ('ADMISSIONAL', 'PERIODICO', 'RETORNO_TRABALHO', 'MUDANCA_RISCO', 'DEMISSIONAL')),
  exam_date DATE NOT NULL,
  result TEXT NOT NULL CHECK (result IN ('APTO', 'INAPTO', 'APTO_COM_RESTRICAO')),
  restrictions_description TEXT,
  doctor_name TEXT NOT NULL,
  doctor_crm TEXT NOT NULL,
  doctor_uf TEXT NOT NULL,
  is_coordinator_doctor BOOLEAN DEFAULT false,
  complementary_exams JSONB DEFAULT '[]'::jsonb,
  esocial_receipt_number TEXT,
  esocial_status TEXT DEFAULT 'PENDING' CHECK (esocial_status IN ('PENDING', 'GENERATED', 'TRANSMITTED', 'ACCEPTED', 'REJECTED')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 17. ACCIDENTS & CAT (S-2210)
CREATE TABLE IF NOT EXISTS public.sst_accidents (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  client_id UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  employee_id UUID REFERENCES public.sst_employees(id) ON DELETE SET NULL,
  type TEXT NOT NULL CHECK (type IN ('TIPICO', 'TRAJETO', 'DOENCA_OCUPACIONAL', 'QUASE_ACIDENTE')),
  severity TEXT NOT NULL CHECK (severity IN ('LEVE', 'MODERADA', 'GRAVE', 'FATAL', 'CRITICA')),
  accident_date DATE NOT NULL,
  accident_time TIME,
  location TEXT NOT NULL,
  description TEXT NOT NULL,
  days_lost INTEGER DEFAULT 0,
  police_report_filed BOOLEAN DEFAULT false,
  root_cause_ishikawa JSONB DEFAULT '{}'::jsonb,
  root_cause_5whys JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.sst_cats (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  accident_id UUID REFERENCES public.sst_accidents(id) ON DELETE SET NULL,
  client_id UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  employee_id UUID NOT NULL REFERENCES public.sst_employees(id) ON DELETE CASCADE,
  cat_type TEXT DEFAULT 'INICIAL' CHECK (cat_type IN ('INICIAL', 'REABERTURA', 'OBITO')),
  accident_date DATE NOT NULL,
  body_part_code TEXT NOT NULL,
  body_part_name TEXT NOT NULL,
  causative_agent_code TEXT NOT NULL,
  causative_agent_name TEXT NOT NULL,
  cid10_code TEXT NOT NULL,
  cid10_description TEXT,
  medical_attendant_name TEXT,
  crm_number TEXT,
  leaves_days INTEGER DEFAULT 0,
  cat_number TEXT,
  receipt_number TEXT,
  esocial_status TEXT DEFAULT 'PENDING' CHECK (esocial_status IN ('PENDING', 'GENERATED', 'TRANSMITTED', 'ACCEPTED', 'REJECTED')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 18. TRAININGS & CERTIFICATES
CREATE TABLE IF NOT EXISTS public.sst_trainings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  client_id UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  norm_code TEXT NOT NULL,
  training_name TEXT NOT NULL,
  course_modality TEXT CHECK (course_modality IN ('PRESENCIAL', 'EAD', 'SEMIPRESENCIAL')),
  workload_hours NUMERIC(5,1) NOT NULL,
  instructor_name TEXT NOT NULL,
  instructor_qualification TEXT,
  start_date DATE NOT NULL,
  completion_date DATE NOT NULL,
  validity_months INTEGER DEFAULT 12,
  syllabus JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.sst_certificates (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  training_id UUID NOT NULL REFERENCES public.sst_trainings(id) ON DELETE CASCADE,
  employee_id UUID NOT NULL REFERENCES public.sst_employees(id) ON DELETE CASCADE,
  certificate_number TEXT NOT NULL UNIQUE,
  validation_code TEXT NOT NULL,
  issue_date DATE NOT NULL,
  expiration_date DATE,
  file_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 19. CIPA PROCESSES (NR-05 & Setoriais)
CREATE TABLE IF NOT EXISTS public.cipa_processes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  client_id UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  norm TEXT NOT NULL DEFAULT 'NR-05' CHECK (norm IN ('NR-05', 'NR-18', 'NR-31', 'NR-32', 'NR-22', 'NR-29', 'NR-30', 'NR-37')),
  mandate_year TEXT NOT NULL,
  status TEXT DEFAULT 'EDICT_ISSUED' CHECK (status IN ('COMMISSION_FORMED', 'EDICT_ISSUED', 'REGISTRATION_OPEN', 'VOTING_IN_PROGRESS', 'VOTING_CLOSED', 'RESULTS_PUBLISHED', 'INAUGURATED', 'ARCHIVED')),
  dimensioning JSONB NOT NULL DEFAULT '{}'::jsonb,
  timeline JSONB NOT NULL DEFAULT '{}'::jsonb,
  employer_appointees JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.cipa_candidates (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  process_id UUID NOT NULL REFERENCES public.cipa_processes(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  cpf TEXT NOT NULL,
  job_title TEXT NOT NULL,
  department TEXT NOT NULL,
  votes_count INTEGER DEFAULT 0,
  elected_role TEXT CHECK (elected_role IN ('VICE_PRESIDENT', 'EFFECTIVE', 'SUBSTITUTE', 'NOT_ELECTED')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.cipa_meetings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  process_id UUID NOT NULL REFERENCES public.cipa_processes(id) ON DELETE CASCADE,
  meeting_number INTEGER NOT NULL,
  type TEXT DEFAULT 'ORDINARY' CHECK (type IN ('ORDINARY', 'EXTRAORDINARY')),
  date DATE NOT NULL,
  title TEXT NOT NULL,
  agenda_topics JSONB DEFAULT '[]'::jsonb,
  attendees_count INTEGER DEFAULT 0,
  ata_document_sha256 TEXT,
  is_signed_by_all BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 20. ACTION PLANS 5W2H
CREATE TABLE IF NOT EXISTS public.sst_action_plans (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  client_id UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  origin_type TEXT NOT NULL CHECK (origin_type IN ('PGR', 'PCMSO', 'CIPA', 'ACCIDENT', 'AUDIT', 'INSPECTION')),
  origin_id UUID,
  what TEXT NOT NULL,
  why TEXT NOT NULL,
  where_location TEXT NOT NULL,
  who_responsible TEXT NOT NULL,
  when_due_date DATE NOT NULL,
  how_method TEXT NOT NULL,
  how_much_cost NUMERIC(10,2) DEFAULT 0.00,
  status TEXT DEFAULT 'PENDENTE' CHECK (status IN ('PENDENTE', 'EM_ANDAMENTO', 'CONCLUIDO', 'ATRASADO', 'CANCELADO')),
  completion_date DATE,
  evidence_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 21. DOCUMENTS, REQUESTS, NOTIFICATIONS & AUDIT
CREATE TABLE IF NOT EXISTS public.documents (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organization_id UUID REFERENCES public.organizations(id) ON DELETE CASCADE,
  service_order_id UUID REFERENCES public.service_orders(id) ON DELETE SET NULL,
  client_id UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  doc_number TEXT NOT NULL,
  name TEXT NOT NULL,
  document_type TEXT NOT NULL,
  current_version INTEGER DEFAULT 1,
  file_url TEXT,
  file_hash TEXT,
  status TEXT DEFAULT 'DRAFT' CHECK (status IN ('DRAFT', 'UNDER_REVIEW', 'APPROVED', 'PUBLISHED', 'ARCHIVED')),
  is_client_released BOOLEAN DEFAULT false,
  versions JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.requests (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organization_id UUID REFERENCES public.organizations(id) ON DELETE CASCADE,
  client_id UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  service_order_id UUID REFERENCES public.service_orders(id) ON DELETE SET NULL,
  stage_id TEXT,
  title TEXT NOT NULL,
  description TEXT,
  type TEXT DEFAULT 'DOCUMENT' CHECK (type IN ('DOCUMENT', 'INFORMATION', 'SIGNATURE', 'CONFIRMATION')),
  priority TEXT DEFAULT 'MEDIUM' CHECK (priority IN ('LOW', 'MEDIUM', 'HIGH', 'URGENT')),
  status TEXT DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'UPLOADED', 'ACCEPTED', 'REJECTED')),
  due_date DATE NOT NULL,
  fulfilled_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- INDEXES
CREATE INDEX IF NOT EXISTS idx_clients_org ON public.clients(organization_id);
CREATE INDEX IF NOT EXISTS idx_employees_client ON public.sst_employees(client_id);
CREATE INDEX IF NOT EXISTS idx_employees_cpf ON public.sst_employees(cpf);
CREATE INDEX IF NOT EXISTS idx_pgr_client ON public.sst_pgr_inventory(client_id);
CREATE INDEX IF NOT EXISTS idx_asos_client_emp ON public.sst_asos(client_id, employee_id);
CREATE INDEX IF NOT EXISTS idx_accidents_client ON public.sst_accidents(client_id);
CREATE INDEX IF NOT EXISTS idx_trainings_client ON public.sst_trainings(client_id);
CREATE INDEX IF NOT EXISTS idx_cipa_client ON public.cipa_processes(client_id);
CREATE INDEX IF NOT EXISTS idx_service_orders_client ON public.service_orders(client_id);
CREATE INDEX IF NOT EXISTS idx_service_orders_due_date ON public.service_orders(due_date);
CREATE INDEX IF NOT EXISTS idx_documents_client ON public.documents(client_id);

-- TRIGGERS
CREATE TRIGGER trigger_org_upd BEFORE UPDATE ON public.organizations FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER trigger_cli_upd BEFORE UPDATE ON public.clients FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER trigger_emp_upd BEFORE UPDATE ON public.sst_employees FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER trigger_os_upd BEFORE UPDATE ON public.service_orders FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER trigger_pgr_upd BEFORE UPDATE ON public.sst_pgr_inventory FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER trigger_aso_upd BEFORE UPDATE ON public.sst_asos FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER trigger_cipa_upd BEFORE UPDATE ON public.cipa_processes FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
