'use client';

import React, { useState } from 'react';
import { usePrevSafe } from '@/context/PrevSafeContext';
import { SSTGroupHomogeneousExposure, SSTEnvironmentalRisk, RiskCategoryType } from '@/types';
import { 
  ShieldAlert, 
  Plus, 
  Trash2, 
  Edit3, 
  Search, 
  AlertTriangle, 
  CheckCircle2, 
  Activity, 
  Zap, 
  Eye, 
  FileCode2, 
  HardHat, 
  Sparkles,
  Layers,
  ChevronRight,
  Info
} from 'lucide-react';

interface GHERiskInventoryTabProps {
  selectedClientId: string;
}

export const GHERiskInventoryTab: React.FC<GHERiskInventoryTabProps> = ({ selectedClientId }) => {
  const {
    ghes,
    environmentalRisks,
    hierarchySectors,
    hierarchyJobs,
    employees,
    addGhe,
    updateGhe,
    deleteGhe,
    addEnvironmentalRisk,
    updateEnvironmentalRisk,
    deleteEnvironmentalRisk,
    generateS2240FromGhe
  } = usePrevSafe();

  const clientGhes = ghes.filter(g => !selectedClientId || g.client_id === selectedClientId);
  const [selectedGheId, setSelectedGheId] = useState<string>(clientGhes[0]?.id || '');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState<string>('ALL');

  // GHE Modal
  const [isGheModalOpen, setIsGheModalOpen] = useState(false);
  const [editingGhe, setEditingGhe] = useState<SSTGroupHomogeneousExposure | null>(null);
  const [gheForm, setGheForm] = useState<{
    code: string;
    name: string;
    description: string;
    sector_ids: string[];
    job_ids: string[];
    work_schedule_description: string;
    environment_description: string;
  }>({
    code: '',
    name: '',
    description: '',
    sector_ids: [],
    job_ids: [],
    work_schedule_description: 'Jornada regular: 44h semanais, 07:00 às 17:00 com 1h intervalo',
    environment_description: 'Galpão industrial fechado, piso nivelado, ventilação natural e exaustão mecânica'
  });

  // Risk Modal
  const [isRiskModalOpen, setIsRiskModalOpen] = useState(false);
  const [editingRisk, setEditingRisk] = useState<SSTEnvironmentalRisk | null>(null);
  const [riskForm, setRiskForm] = useState<{
    risk_category: RiskCategoryType;
    agent_name: string;
    risk_code_table_24: string;
    generating_source: string;
    propagation_path: string;
    health_effects: string;
    evaluation_type: 'QUALITATIVA' | 'QUANTITATIVA';
    measurement_unit: string;
    measured_value: string;
    tolerance_limit: string;
    action_level: string;
    measurement_methodology: string;
    severity: 1 | 2 | 3 | 4 | 5;
    probability: 1 | 2 | 3 | 4 | 5;
    epc_implemented: boolean;
    epc_description: string;
    epi_required: boolean;
    ca_number_input: string;
    epi_name_input: string;
    special_retirement_applies: boolean;
    gfip_code: '00' | '01' | '02' | '03' | '04';
    ltcat_technical_conclusion: string;
    insalubridade_applies: boolean;
    insalubridade_degree: '10%' | '20%' | '40%';
    periculosidade_applies: boolean;
  }>({
    risk_category: 'FÍSICO',
    agent_name: 'Ruído Contínuo ou Intermitente',
    risk_code_table_24: '01.01.001',
    generating_source: 'Operação simultânea de maquinários rotativos e prensas mecânicas',
    propagation_path: 'Aérea',
    health_effects: 'Perda auditiva induzida por ruído (PAIR), estresse, cefaleia',
    evaluation_type: 'QUANTITATIVA',
    measurement_unit: 'dB(A)',
    measured_value: '84.5',
    tolerance_limit: '85.0 dB(A) para 8h (NR-15 Anexo 1)',
    action_level: '80.0 dB(A) (NR-09)',
    measurement_methodology: 'Dosímetro de ruído integrador classe 1 conforme NHO-01 Fundacentro',
    severity: 3,
    probability: 3,
    epc_implemented: true,
    epc_description: 'Enclausuramento acústico de compressores e exaustores',
    epi_required: true,
    ca_number_input: '14235',
    epi_name_input: 'Protetor Auditivo tipo Plug de Silicone 16dB',
    special_retirement_applies: false,
    gfip_code: '00',
    ltcat_technical_conclusion: 'Exposição abaixo do limite de tolerância após atenuação eficaz dos EPIs (NR-15 e Dec 3.048/99).',
    insalubridade_applies: false,
    insalubridade_degree: '20%',
    periculosidade_applies: false
  });

  const [generatedS2240Success, setGeneratedS2240Success] = useState<string | null>(null);

  const activeGhe = clientGhes.find(g => g.id === selectedGheId) || clientGhes[0];
  const gheRisks = environmentalRisks.filter(r => r.ghe_id === activeGhe?.id);
  
  const filteredRisks = gheRisks.filter(r => {
    if (filterCategory !== 'ALL' && r.risk_category !== filterCategory) return false;
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      return r.agent_name.toLowerCase().includes(q) || 
             r.risk_code_table_24.includes(q) ||
             r.generating_source.toLowerCase().includes(q);
    }
    return true;
  });

  const handleOpenGheModal = (ghe?: SSTGroupHomogeneousExposure) => {
    if (ghe) {
      setEditingGhe(ghe);
      setGheForm({
        code: ghe.code,
        name: ghe.name,
        description: ghe.description || '',
        sector_ids: ghe.sector_ids || [],
        job_ids: ghe.job_ids || [],
        work_schedule_description: ghe.work_schedule_description || '44h semanais',
        environment_description: ghe.environment_description || ''
      });
    } else {
      setEditingGhe(null);
      setGheForm({
        code: `GHE-${String(clientGhes.length + 1).padStart(2, '0')}`,
        name: '',
        description: '',
        sector_ids: hierarchySectors.slice(0, 1).map(s => s.id),
        job_ids: hierarchyJobs.slice(0, 2).map(j => j.id),
        work_schedule_description: 'Jornada regular: 44h semanais, 07:00 às 17:00 com 1h intervalo',
        environment_description: 'Galpão industrial fechado, piso nivelado, iluminação adequada conforme NR-17'
      });
    }
    setIsGheModalOpen(true);
  };

  const handleSaveGhe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!gheForm.name || !gheForm.code) return;

    if (editingGhe) {
      updateGhe(editingGhe.id, gheForm);
    } else {
      const created = addGhe({
        client_id: selectedClientId || 'cli-valenca-01',
        client_unit_id: 'unit-01',
        ...gheForm,
        total_exposed_workers: employees.filter(emp => !selectedClientId || emp.client_id === selectedClientId).length || 5
      });
      setSelectedGheId(created.id);
    }
    setIsGheModalOpen(false);
  };

  const handleOpenRiskModal = (risk?: SSTEnvironmentalRisk) => {
    if (risk) {
      setEditingRisk(risk);
      setRiskForm({
        risk_category: risk.risk_category,
        agent_name: risk.agent_name,
        risk_code_table_24: risk.risk_code_table_24,
        generating_source: risk.generating_source,
        propagation_path: risk.propagation_path || 'Aérea',
        health_effects: risk.health_effects || '',
        evaluation_type: risk.evaluation_type,
        measurement_unit: risk.measurement_unit || '',
        measured_value: risk.measured_value || '',
        tolerance_limit: risk.tolerance_limit || '',
        action_level: risk.action_level || '',
        measurement_methodology: risk.measurement_methodology || '',
        severity: risk.severity || 3,
        probability: risk.probability || 3,
        epc_implemented: risk.epc_implemented,
        epc_description: risk.epc_description || '',
        epi_required: risk.epi_required,
        ca_number_input: risk.epis?.[0]?.ca_number || '',
        epi_name_input: risk.epis?.[0]?.epi_name || '',
        special_retirement_applies: risk.special_retirement_applies,
        gfip_code: risk.gfip_code || '00',
        ltcat_technical_conclusion: risk.ltcat_technical_conclusion || '',
        insalubridade_applies: risk.insalubridade_applies,
        insalubridade_degree: risk.insalubridade_degree || '20%',
        periculosidade_applies: risk.periculosidade_applies
      });
    } else {
      setEditingRisk(null);
      setRiskForm({
        risk_category: 'FÍSICO',
        agent_name: 'Ruído Contínuo ou Intermitente',
        risk_code_table_24: '01.01.001',
        generating_source: 'Operação simultânea de maquinários rotativos e prensas mecânicas',
        propagation_path: 'Aérea',
        health_effects: 'Perda auditiva induzida por ruído (PAIR), estresse, cefaleia',
        evaluation_type: 'QUANTITATIVA',
        measurement_unit: 'dB(A)',
        measured_value: '84.5',
        tolerance_limit: '85.0 dB(A) para 8h (NR-15 Anexo 1)',
        action_level: '80.0 dB(A) (NR-09)',
        measurement_methodology: 'Dosímetro de ruído integrador classe 1 conforme NHO-01 Fundacentro',
        severity: 3,
        probability: 3,
        epc_implemented: true,
        epc_description: 'Enclausuramento acústico de compressores e exaustores',
        epi_required: true,
        ca_number_input: '14235',
        epi_name_input: 'Protetor Auditivo tipo Plug de Silicone 16dB',
        special_retirement_applies: false,
        gfip_code: '00',
        ltcat_technical_conclusion: 'Exposição controlada com fornecimento e uso obrigatório de EPI eficaz.',
        insalubridade_applies: false,
        insalubridade_degree: '20%',
        periculosidade_applies: false
      });
    }
    setIsRiskModalOpen(true);
  };

  const handleSaveRisk = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeGhe || !riskForm.agent_name || !riskForm.risk_code_table_24) return;

    const riskScore = riskForm.severity * riskForm.probability;
    let risk_level: 'MUITO_BAIXO' | 'BAIXO' | 'MEDIO' | 'ALTO' | 'CRITICO' = 'MEDIO';
    if (riskScore <= 3) risk_level = 'MUITO_BAIXO';
    else if (riskScore <= 8) risk_level = 'BAIXO';
    else if (riskScore <= 14) risk_level = 'MEDIO';
    else if (riskScore <= 20) risk_level = 'ALTO';
    else risk_level = 'CRITICO';

    const epis = riskForm.epi_required && riskForm.ca_number_input ? [
      {
        ca_number: riskForm.ca_number_input,
        epi_name: riskForm.epi_name_input || 'EPI Regulamentado com CA',
        is_effective: true,
        complies_with_nr06: true,
        uninterrupted_use: true,
        periodic_replacement: true,
        hygienic_conditions: true
      }
    ] : [];

    const riskPayload = {
      client_id: activeGhe.client_id,
      client_unit_id: activeGhe.client_unit_id || 'unit-01',
      ghe_id: activeGhe.id,
      risk_category: riskForm.risk_category,
      risk_code_table_24: riskForm.risk_code_table_24,
      agent_name: riskForm.agent_name,
      generating_source: riskForm.generating_source,
      propagation_path: riskForm.propagation_path,
      health_effects: riskForm.health_effects,
      evaluation_type: riskForm.evaluation_type,
      measured_value: riskForm.measured_value || undefined,
      measurement_unit: riskForm.measurement_unit || undefined,
      tolerance_limit: riskForm.tolerance_limit || undefined,
      action_level: riskForm.action_level || undefined,
      measurement_methodology: riskForm.measurement_methodology || undefined,
      probability: riskForm.probability,
      severity: riskForm.severity,
      risk_level,
      epc_implemented: riskForm.epc_implemented,
      epc_description: riskForm.epc_description || undefined,
      epc_effective: riskForm.epc_implemented,
      epi_required: riskForm.epi_required,
      epis,
      special_retirement_applies: riskForm.special_retirement_applies,
      gfip_code: riskForm.gfip_code,
      ltcat_technical_conclusion: riskForm.ltcat_technical_conclusion,
      insalubridade_applies: riskForm.insalubridade_applies,
      insalubridade_degree: riskForm.insalubridade_degree,
      periculosidade_applies: riskForm.periculosidade_applies,
      status: 'ACTIVE' as const
    };

    if (editingRisk) {
      updateEnvironmentalRisk(editingRisk.id, riskPayload);
    } else {
      addEnvironmentalRisk(riskPayload);
    }
    setIsRiskModalOpen(false);
  };

  const handleGenerateS2240 = () => {
    if (!activeGhe) return;
    const evt = generateS2240FromGhe(activeGhe.id);
    if (evt) {
      setGeneratedS2240Success(`Evento S-2240 (${evt.event_number}) gerado com sucesso para ${activeGhe.name}! Pronto para transmissão.`);
      setTimeout(() => setGeneratedS2240Success(null), 5000);
    }
  };

  return (
    <div className="space-y-6" id="ghe-risk-inventory-tab-container">
      {/* Top Banner Alert for S-2240 */}
      {generatedS2240Success && (
        <div className="p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-xl flex items-center justify-between text-xs text-emerald-300 animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            <span className="font-semibold">{generatedS2240Success}</span>
          </div>
          <span className="text-[11px] bg-emerald-500 text-slate-950 font-bold px-2 py-1 rounded">S-2240 Gerado</span>
        </div>
      )}

      {/* Main Split Layout: Left GHE List, Right Risk Inventory */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Side: GHE Selector and Management (4 cols) */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-lg space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-slate-100 text-sm flex items-center gap-2">
                  <Layers className="w-4 h-4 text-teal-400" />
                  GHE / Grupos de Exposição ({clientGhes.length})
                </h3>
                <p className="text-[11px] text-slate-400">Homogeneidade de riscos para PGR e LTCAT</p>
              </div>
              <button
                type="button"
                id="create-ghe-btn"
                onClick={() => handleOpenGheModal()}
                className="px-2.5 py-1.5 bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs rounded-lg transition-all flex items-center gap-1 shadow-sm"
              >
                <Plus className="w-3.5 h-3.5" />
                Novo GHE
              </button>
            </div>

            <div className="space-y-2 max-h-[600px] overflow-y-auto pr-1">
              {clientGhes.map((ghe) => {
                const isSelected = ghe.id === activeGhe?.id;
                const riskCount = environmentalRisks.filter(r => r.ghe_id === ghe.id).length;

                return (
                  <div
                    key={ghe.id}
                    id={`ghe-card-${ghe.id}`}
                    onClick={() => setSelectedGheId(ghe.id)}
                    className={`p-3 rounded-xl border cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-teal-500/10 border-teal-500/40 text-slate-100 shadow-md'
                        : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700 hover:bg-slate-800/40'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="space-y-1">
                        <div className="flex items-center gap-1.5">
                          <span className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded ${
                            isSelected ? 'bg-teal-500 text-slate-950' : 'bg-slate-800 text-slate-400'
                          }`}>
                            {ghe.code}
                          </span>
                          <span className="font-bold text-xs">{ghe.name}</span>
                        </div>
                        <p className="text-[11px] text-slate-400 line-clamp-2">{ghe.description || 'Ambiente fabril com riscos físicos e químicos mapeados.'}</p>
                      </div>

                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={(e) => { e.stopPropagation(); handleOpenGheModal(ghe); }}
                          className="p-1 text-slate-400 hover:text-teal-400 rounded"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={(e) => { e.stopPropagation(); deleteGhe(ghe.id); }}
                          className="p-1 text-slate-400 hover:text-rose-400 rounded"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-[10px] text-slate-400 mt-2 pt-2 border-t border-slate-800/60">
                      <span>Riscos caracterizados: <strong className="text-teal-400">{riskCount}</strong></span>
                      <span className="flex items-center gap-1">
                        Ver Inventário <ChevronRight className="w-3 h-3" />
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Side: Active GHE Detailed Risk Inventory (8 cols) */}
        <div className="lg:col-span-8 space-y-4">
          {activeGhe ? (
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-5">
              {/* Header GHE Details */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 bg-teal-500 text-slate-950 font-bold text-xs font-mono rounded">
                      {activeGhe.code}
                    </span>
                    <h3 className="font-bold text-base text-slate-100">{activeGhe.name}</h3>
                  </div>
                  <p className="text-xs text-slate-400 mt-1">{activeGhe.description}</p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    id="gen-s2240-btn"
                    onClick={handleGenerateS2240}
                    className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 shadow-sm"
                  >
                    <FileCode2 className="w-4 h-4" />
                    Gerar S-2240 (XML)
                  </button>
                  <button
                    type="button"
                    id="add-risk-btn"
                    onClick={() => handleOpenRiskModal()}
                    className="px-3 py-1.5 bg-teal-500 hover:bg-teal-400 text-slate-950 text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 shadow-sm"
                  >
                    <Plus className="w-4 h-4" />
                    Caracterizar Risco
                  </button>
                </div>
              </div>

              {/* Filters & Search */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1">
                  {['ALL', 'FÍSICO', 'QUÍMICO', 'BIOLÓGICO', 'ERGONÔMICO', 'ACIDENTES'].map((cat) => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setFilterCategory(cat)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                        filterCategory === cat
                          ? 'bg-teal-500 text-slate-950'
                          : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>

                <div className="relative w-full sm:w-64">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Buscar agente, código ou fonte..."
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-teal-500"
                  />
                </div>
              </div>

              {/* Risk Cards List */}
              <div className="space-y-3" id="risk-inventory-list">
                {filteredRisks.length === 0 ? (
                  <div className="text-center py-10 bg-slate-950/40 rounded-xl border border-slate-800/80 p-6 space-y-2">
                    <ShieldAlert className="w-8 h-8 text-slate-500 mx-auto" />
                    <p className="text-sm font-semibold text-slate-300">Nenhum risco ambiental caracterizado para este GHE</p>
                    <p className="text-xs text-slate-500">Clique em &ldquo;Caracterizar Risco&rdquo; para adicionar ruído, calor, produtos químicos ou agentes de acidentes.</p>
                  </div>
                ) : (
                  filteredRisks.map((risk) => (
                    <div
                      key={risk.id}
                      id={`risk-card-${risk.id}`}
                      className="bg-slate-950 border border-slate-800/80 hover:border-slate-700 rounded-xl p-4 space-y-3 transition-all"
                    >
                      <div className="flex items-start justify-between">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="px-2 py-0.5 bg-amber-500/10 border border-amber-500/30 text-amber-300 text-[10px] font-bold font-mono rounded">
                              Tabela 24: {risk.risk_code_table_24}
                            </span>
                            <span className="px-2 py-0.5 bg-slate-800 text-slate-300 text-[10px] font-semibold rounded">
                              {risk.risk_category}
                            </span>
                            <span className="text-xs font-bold text-slate-100">{risk.agent_name}</span>
                          </div>
                          <p className="text-xs text-slate-400">
                            <strong>Fonte Geradora:</strong> {risk.generating_source}
                          </p>
                        </div>

                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => handleOpenRiskModal(risk)}
                            className="p-1.5 text-slate-400 hover:text-teal-400 hover:bg-slate-800 rounded transition-colors"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => deleteEnvironmentalRisk(risk.id)}
                            className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {/* Metrics & Controls Grid */}
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-slate-800/60 text-xs">
                        <div className="bg-slate-900/60 p-2 rounded border border-slate-800">
                          <span className="text-[10px] text-slate-500 block font-semibold">Avaliação</span>
                          <span className="font-bold text-slate-200">{risk.evaluation_type}</span>
                          {risk.measured_value && (
                            <span className="text-[11px] text-teal-400 block font-mono">
                              {risk.measured_value} {risk.measurement_unit}
                            </span>
                          )}
                        </div>

                        <div className="bg-slate-900/60 p-2 rounded border border-slate-800">
                          <span className="text-[10px] text-slate-500 block font-semibold">Matriz de Risco</span>
                          <span className="font-bold text-amber-400">{risk.risk_level}</span>
                          <span className="text-[10px] text-slate-400 block">P{risk.probability} x S{risk.severity}</span>
                        </div>

                        <div className="bg-slate-900/60 p-2 rounded border border-slate-800">
                          <span className="text-[10px] text-slate-500 block font-semibold">EPI / EPC</span>
                          <span className="text-slate-200 block text-[11px]">
                            {risk.epi_required ? `EPI: CA ${risk.epis?.[0]?.ca_number || 'Sim'}` : 'EPI: Não'}
                          </span>
                          <span className="text-[10px] text-slate-400 block">
                            EPC: {risk.epc_implemented ? 'Ativo' : 'Não'}
                          </span>
                        </div>

                        <div className="bg-slate-900/60 p-2 rounded border border-slate-800">
                          <span className="text-[10px] text-slate-500 block font-semibold">LTCAT / GFIP</span>
                          <span className="font-mono text-slate-200 block text-[11px]">GFIP: {risk.gfip_code || '00'}</span>
                          <span className="text-[10px] text-emerald-400 block font-semibold">
                            {risk.special_retirement_applies ? 'Aposentadoria Especial' : 'Sem Aposentadoria'}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          ) : (
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 text-center text-slate-400">
              Selecione ou crie um GHE para visualizar e gerenciar seu inventário de riscos.
            </div>
          )}
        </div>
      </div>

      {/* GHE Modal */}
      {isGheModalOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <Layers className="w-5 h-5 text-teal-400" />
                {editingGhe ? 'Editar Grupo de Exposição (GHE)' : 'Cadastrar Novo GHE'}
              </h3>
              <button 
                type="button" 
                onClick={() => setIsGheModalOpen(false)}
                className="text-slate-400 hover:text-slate-200 text-sm font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveGhe} className="space-y-4 text-xs">
              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-1">
                  <label className="block text-slate-400 font-semibold mb-1">Código GHE</label>
                  <input
                    type="text"
                    required
                    placeholder="GHE-01"
                    value={gheForm.code}
                    onChange={(e) => setGheForm({ ...gheForm, code: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 font-mono focus:outline-none focus:border-teal-500"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-slate-400 font-semibold mb-1">Nome do GHE</label>
                  <input
                    type="text"
                    required
                    placeholder="GHE 01 - Soldadores e Mecânicos"
                    value={gheForm.name}
                    onChange={(e) => setGheForm({ ...gheForm, name: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-teal-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">Descrição do Grupo e Atividades</label>
                <textarea
                  rows={2}
                  value={gheForm.description}
                  onChange={(e) => setGheForm({ ...gheForm, description: e.target.value })}
                  placeholder="Descreva as tarefas e postos de trabalho..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-teal-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">Descrição do Ambiente Físico (PGR/LTCAT)</label>
                <textarea
                  rows={2}
                  value={gheForm.environment_description}
                  onChange={(e) => setGheForm({ ...gheForm, environment_description: e.target.value })}
                  placeholder="Estrutura, piso, ventilação, iluminação..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-teal-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">Jornada de Trabalho e Escala</label>
                <input
                  type="text"
                  value={gheForm.work_schedule_description}
                  onChange={(e) => setGheForm({ ...gheForm, work_schedule_description: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-teal-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsGheModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold rounded-lg"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold rounded-lg shadow-md"
                >
                  Salvar GHE
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Risk Characterization Modal */}
      {isRiskModalOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 space-y-4 shadow-2xl animate-in fade-in zoom-in-95 duration-150 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <ShieldAlert className="w-5 h-5 text-teal-400" />
                {editingRisk ? 'Editar Caracterização do Risco' : 'Caracterizar Novo Fator de Risco (PGR / S-2240)'}
              </h3>
              <button 
                type="button" 
                onClick={() => setIsRiskModalOpen(false)}
                className="text-slate-400 hover:text-slate-200 text-sm font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveRisk} className="space-y-4 text-xs">
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Categoria do Risco</label>
                  <select
                    value={riskForm.risk_category}
                    onChange={(e) => setRiskForm({ ...riskForm, risk_category: e.target.value as any })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-teal-500 font-bold"
                  >
                    <option value="FÍSICO">Físico</option>
                    <option value="QUÍMICO">Químico</option>
                    <option value="BIOLÓGICO">Biológico</option>
                    <option value="ERGONÔMICO">Ergonômico</option>
                    <option value="ACIDENTES">Acidentes / Mecânicos</option>
                    <option value="AUSÊNCIA_RISCO">Ausência de Risco</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Código Tabela 24 eSocial</label>
                  <input
                    type="text"
                    required
                    placeholder="01.01.001"
                    value={riskForm.risk_code_table_24}
                    onChange={(e) => setRiskForm({ ...riskForm, risk_code_table_24: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 font-mono focus:outline-none focus:border-teal-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Nome do Agente Nocivo</label>
                  <input
                    type="text"
                    required
                    value={riskForm.agent_name}
                    onChange={(e) => setRiskForm({ ...riskForm, agent_name: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-teal-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">Fonte Geradora do Risco</label>
                <input
                  type="text"
                  required
                  value={riskForm.generating_source}
                  onChange={(e) => setRiskForm({ ...riskForm, generating_source: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-teal-500"
                />
              </div>

              {/* Quantification & Limits */}
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                <h4 className="font-bold text-slate-200 text-xs flex items-center gap-1.5">
                  <Activity className="w-4 h-4 text-teal-400" />
                  Avaliação e Métricas de Exposição
                </h4>
                <div className="grid grid-cols-4 gap-3">
                  <div>
                    <label className="block text-slate-400 font-semibold mb-1">Tipo de Avaliação</label>
                    <select
                      value={riskForm.evaluation_type}
                      onChange={(e) => setRiskForm({ ...riskForm, evaluation_type: e.target.value as any })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-slate-100"
                    >
                      <option value="QUALITATIVA">Qualitativa</option>
                      <option value="QUANTITATIVA">Quantitativa</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-slate-400 font-semibold mb-1">Valor Medido</label>
                    <input
                      type="text"
                      placeholder="84.5"
                      value={riskForm.measured_value}
                      onChange={(e) => setRiskForm({ ...riskForm, measured_value: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 font-semibold mb-1">Unidade de Medida</label>
                    <input
                      type="text"
                      placeholder="dB(A)"
                      value={riskForm.measurement_unit}
                      onChange={(e) => setRiskForm({ ...riskForm, measurement_unit: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-slate-100"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 font-semibold mb-1">Limite Tolerância</label>
                    <input
                      type="text"
                      placeholder="85.0"
                      value={riskForm.tolerance_limit}
                      onChange={(e) => setRiskForm({ ...riskForm, tolerance_limit: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* EPI and Control measures */}
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                <h4 className="font-bold text-slate-200 text-xs flex items-center gap-1.5">
                  <HardHat className="w-4 h-4 text-teal-400" />
                  Medidas de Proteção e EPIs (eSocial)
                </h4>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-400 font-semibold mb-1">Nº do C.A. do EPI</label>
                    <input
                      type="text"
                      placeholder="14235"
                      value={riskForm.ca_number_input}
                      onChange={(e) => setRiskForm({ ...riskForm, ca_number_input: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 font-semibold mb-1">Descrição do EPI</label>
                    <input
                      type="text"
                      placeholder="Protetor Auricular tipo Plug"
                      value={riskForm.epi_name_input}
                      onChange={(e) => setRiskForm({ ...riskForm, epi_name_input: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-slate-100"
                    />
                  </div>
                </div>
              </div>

              {/* Special Enquadramentos */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Código GFIP (SEFIP / eSocial)</label>
                  <select
                    value={riskForm.gfip_code}
                    onChange={(e) => setRiskForm({ ...riskForm, gfip_code: e.target.value as any })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 font-mono"
                  >
                    <option value="00">00 - Sem exposição a agente nocivo</option>
                    <option value="01">01 - Não enseja aposentadoria especial</option>
                    <option value="02">02 - Enseja aposentadoria especial (15 anos)</option>
                    <option value="03">03 - Enseja aposentadoria especial (20 anos)</option>
                    <option value="04">04 - Enseja aposentadoria especial (25 anos)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Conclusão Técnica LTCAT</label>
                  <input
                    type="text"
                    value={riskForm.ltcat_technical_conclusion}
                    onChange={(e) => setRiskForm({ ...riskForm, ltcat_technical_conclusion: e.target.value })}
                    placeholder="Conclusão da exposição..."
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-100"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsRiskModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold rounded-lg"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold rounded-lg shadow-md"
                >
                  Salvar Caracterização
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
